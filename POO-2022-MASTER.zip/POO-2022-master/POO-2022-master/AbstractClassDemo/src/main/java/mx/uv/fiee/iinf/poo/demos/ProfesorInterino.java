package mx.uv.fiee.iinf.poo.demos;

public class ProfesorInterino extends Profesor {

    @Override
    public double importeNomina() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
