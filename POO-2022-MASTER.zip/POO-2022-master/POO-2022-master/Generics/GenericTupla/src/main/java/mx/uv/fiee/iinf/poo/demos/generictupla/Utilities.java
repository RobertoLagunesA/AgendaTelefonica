package mx.uv.fiee.iinf.poo.demos.generictupla;

public class Utilities {

    public static <T> boolean compare (T o1, T o2) {
        return o1.equals (o2);
    }

}
