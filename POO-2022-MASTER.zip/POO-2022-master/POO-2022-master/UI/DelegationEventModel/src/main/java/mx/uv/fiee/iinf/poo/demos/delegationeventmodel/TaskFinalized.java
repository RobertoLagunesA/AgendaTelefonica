package mx.uv.fiee.iinf.poo.demos.delegationeventmodel;

public interface TaskFinalized {
    void notificate ();
}