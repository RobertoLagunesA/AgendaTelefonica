package mx.uv.fiee.iinf.poo.demos.awtlayoutsbasics;

public class Main {

    public static void main (String [] args) {
        new SimpleAWTFrame ();
    }
    
}