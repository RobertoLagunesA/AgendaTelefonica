package mx.uv.fiee.iinf.poo;

/**
 * IChair implementation with procedure needed to build a Modern Chair
 */
public class ModernChair implements IChair {
    @Override
    public void chairProps () {
        System.out.println ("Modern Chair Created!");
    }
}
