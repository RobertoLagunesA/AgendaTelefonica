package mx.uv.fiee.iinf.nopattern;

public class NoSQLEngine {

    public void createNoSQLEngine () {
        System.out.println ("NoSQL Engine Created!");
    }

}
