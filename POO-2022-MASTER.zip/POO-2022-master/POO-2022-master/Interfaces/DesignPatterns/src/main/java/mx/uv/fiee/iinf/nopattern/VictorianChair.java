package mx.uv.fiee.iinf.nopattern;

public class VictorianChair {

    public void createVictorianChair () {
        System.out.println ("Victorian Chair Created!");
    }

}
