package mx.uv.fiee.iinf.poo;

/**
 * Abstraction with steps needed to build a chair
 */
public interface IChair {
    void chairProps ();
}
