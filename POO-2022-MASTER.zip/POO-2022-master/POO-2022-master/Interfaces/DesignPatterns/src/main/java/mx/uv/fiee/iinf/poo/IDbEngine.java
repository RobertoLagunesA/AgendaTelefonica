package mx.uv.fiee.iinf.poo;

/**
 * Abstraction with steps to create a DB Engine
 */
public interface IDbEngine {
    void engineProps ();
}
