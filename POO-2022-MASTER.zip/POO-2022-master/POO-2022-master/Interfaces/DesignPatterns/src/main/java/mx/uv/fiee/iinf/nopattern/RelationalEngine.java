package mx.uv.fiee.iinf.nopattern;

public class RelationalEngine {

    public void createRelationalEngine () {
        System.out.println ("Relational Engine Created!");
    }

}
