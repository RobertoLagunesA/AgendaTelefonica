package mx.uv.fiee.iinf.nopattern;

public class ModernChair {

    public void createModernChair () {
        System.out.println ("Modern Chair Created!");
    }

}
