package mx.uv.fiee.iinf.poo;

interface IMinMax<T> {
    T min ();
    T max ();
}